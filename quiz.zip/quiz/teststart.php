<html>
     <head>
	    <title> R U Ready For test</title>
		<link href="css/menu.css" rel="stylesheet" type="text/css">
	 </head>
</html>
<body>
    
	<center>
		<div id="start">
		<a href="sampletests.php"><img src="image/sampletest/play.png" title="start test"></a>
		</div>
		<div id="condition">
				<ul id="rules">
					<li><img src="image/sampletest/time.png" width="50px" height="50px">Time limit is 2 Minutes</li>
					<li><img src="image/sampletest/question.jpg" width="50px" height="50px">Total number of question 10</li>
					<li><img src="image/sampletest/compulsory.jpg" width="50px" height="50px">Every question is Compulsory</li>
					<li><img src="image/sampletest/refresh.png" width="50px" height="50px">Do not Refresh the page until You finish</li>
				</ul>
		</div>
    </center>		

	
</body>
</html>