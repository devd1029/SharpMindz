<!DOCTYPE html>
<html><head>
<title>Feedback form</title>

<head><h1>
Feedback
</h1>

<style>
h1 {
    background-color: green;
}

div {
    background-color: lightblue;
}

p {
    background-color: yellow;
}
</style>
</head>

<body>


<table width="100%">  <tr> <td width="30">&nbsp;</td><td> <table border="0"> <tr><td><span class="style2">

1: 	
The look and feel of the Website such as UI,Design etc</span></td></tr>
<tr><td class="style8">
<input type="radio" name="ans" value="1">A.	Excellent</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="2">B.	Good</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="3">C. Average</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="4">D. Below Average</td></tr><tr><td></td></tr></tbody></table>
</td></table><table width="100%">  <tr> <td width="30">&nbsp;</td><td> <table border="0"> <tr><td><span class="style2">

2:
Would you recommend this Website to your friend</span></td></tr><tr><td class="style8"><input type="radio" name="ans" value="1">
A. Yes</td></tr><tr><td class="style8"> <input type="radio" name="ans" value="2">
B. No </td></tr><tr><td class="style8"></td></tr><tr><td></td></tr></tbody></table>
</td></table><table width="100%">  <tr> <td width="30"></td><td> <table border="0"><tr><td><span class="style2">

3: 	
If you were the reviewer website what score would give out of 5</span></td></tr><tr><td class="style8">
<input type="radio" name="ans" value="1">A.1</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="2">B.2</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="3">C.3</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="4">D.4</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="5">E.5</td></tr></tbody></table>
</td></tr></tbody></table><table width="100%">  <tr> <td width="30">&nbsp;</td><td> <table border="0"> <tr><td><span class="style2">

4: 	
Easy to Operate</span></td></tr><tr><td class="style8">
<input type="radio" name="ans" value="1">A.Good</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="2">B.Average</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="3">C.Below Average</td></tr><tr><td></td></tr></tbody></table></td></table>
<table width="100%">  <tr> <td width="30">&nbsp;</td><td> <table border="0"> <tr><td><span class="style2">



5: 	
Did you have problem with these sites?</span></td></tr><tr><td class="style8">
<input type="radio" name="ans" value="1">A.Yes</td></tr><tr><td class="style8">
<input type="radio" name="ans" value="2">B.No</td></tr><tr><td></td></tr></tbody></table></td></table>
<table width="100%">  <tr> <td width="30">&nbsp;</td><td> <table border="0"> <tr><td><span class="style2">6: 	


Overall Work of this Sites</span></td></tr><tr><td class="style8"><input type="radio" name="ans" value="1">
A.Good</td></tr><tr><td class="style8"> <input type="radio" name="ans" value="2">
B.Average</td></tr><tr><td class="style8"><input type="radio" name="ans" value="3">
C.Poor</td></tr><tr><td class="style8"><input type="radio" name="ans" value="4">
D.Very Bad</td></tr><tr><td></td></tr></tbody></table></td></tr></tbody></table>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Any Suggestion from your'll to make our website user friendly:


<form id="form1" name="form1" method="post" action="">
<label>
<pre>              <textarea name="input" id="input" cols="45" rows="5"></textarea></pre>
</label>
</form>
<form id="form2" name="form2" method="post" action="">
<label>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="export" id="export" value="Submit" />
</label>
</form>



</html>