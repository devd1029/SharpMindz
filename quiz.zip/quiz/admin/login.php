<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Adminstrative AreaOnline Quiz </title>
<link href="../quiz.css" rel="stylesheet" type="text/css">
<link href="adminstyle.css" rel="stylesheet" type="text/css">
</head>

<body  >
<div id="body1">
	<?php
	include("header.php");
	extract($_POST);
	if(isset($submit))
	{
		include("../database.php");
		$rs=mysql_query("select * from mst_admin where loginid='$loginid' and pass='$pass'",$connection) or die(mysql_error());
		if(mysql_num_rows($rs)<1)
		{
			echo "<BR><BR><BR><BR><div class=head1> Invalid User Name or Password<div>";
			exit;
			
		}
		$_SESSION['alogin']="true";
		
	}
	else if(!isset($_SESSION['alogin']))
	{
		echo "<BR><BR><BR><BR><div class=head1> Your are not logged in<br> Please <a href=index.php>Login</a><div>";
			exit;
	}
	?>

	<p class="head1">Welcome to Administrative Area </p>
	<div id="area">
		<section class="set">
				<a href="subadd.php">
				<img src="image/addsub.png" class='module'>
			<p align="center" class="style7">Add Subject</a></p>
		</section>
		<section class="set">
			 <a href="testadd.php">
				<img src="image/addtest.png" class='module'>
			<p align="center" class="style7">Add Test</a></p>
		</section>
		<section class="set">
				<a href="questionadd.php">
				  <img src="image/question.png" class='module'>
			<p align="center" class="style7">Add Question </a></p>
		</section>
		<section class="set">
		   <a href="update.php">
			<img src="image/update.png" class='module'>
			<p align="center" class="style7">update subject </a></p>
		</section>
		<section class="set">
			
			<p align="center" class="head1">&nbsp;</p>
		</section>	
	</div>
 </div>	
</body>
</html>
