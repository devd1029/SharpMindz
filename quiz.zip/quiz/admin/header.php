<link href="adminstyle.css" rel="stylesheet" type="text/css">

  <table width="100%">
  <tr>
    <td align="right">
	<?php
	if(isset($_SESSION['alogin']))
	{
	 ?> 
	 
	 <div align="right" id="headercontent">
	          <a href="login.php">
				  <img src="image/home.png" class="icons"></a>
	          <a href="signout.php">
		         <img src="image/logouts.png" class="icons"></a>
		 
	 </div>
	 <?php
	 }
	 else
	 {
	 				 
	 }
	?>
	</td>
  </tr>
</table>
