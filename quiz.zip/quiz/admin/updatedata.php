<?php

echo"hello friends";
?>