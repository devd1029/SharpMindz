<?php

	if(isset($count))
	{
		
		echo"bhava tuch";
		
	}

?>



<!DOCTYPE html>
	<head>
			<title>Update Question</title>
			<script type="text/javascript">
			   
			   function f1()
			   {
				  
				 window.submit();
				 document.getElementById('form1').action.submit();
			   }
			</script>
	</head>
 <body>	 
	
   

		<?php
		extract($_POST);
	
		   include("header.php");
		  include("../database.php");
			   if(isset($_POST['submit1']))
		   if($_POST['row']==$test_id)
		{
			echo "hello devd";
			echo $_POST['q_id']."<br>";
			echo $_POST['test_id']."<br>";
			echo $_POST['question']."<br>";
			echo $_POST['op1']."<br>";
			echo $_POST['op2']."<br>";
			echo $_POST['op3']."<br>";
			echo $_POST['op4']."<br>";
			echo $_POST['ans']."<br>";
			
		}
	 else{
		 echo "shit code error";
	 }
			 $rs1=mysql_query("Select * from mst_subject",$connection);
			
			echo '<form name="form1" method="POST">';
			echo'<select name="select1" id="select1" onchange="this.form.submit()">';
			echo "<option></option>";
			while($row1=mysql_fetch_array($rs1))
			{  
			    	if($_POST['select1']==$row1['sub_id'])
					{
					   echo "<option value='$row1[sub_id]' selected>$row1[sub_name]</option>";
					}
				else
				{
					echo "<option  value='$row1[sub_id]'>$row1[sub_name]</option>";
				}
			     
					
				
			}
			echo'</select>';
			
				
			
				
				
		
		?>
		
	
     <select name="testselect" onchange="this.form.submit()">	
	<?php
	    
	   
	if (isset($_POST['select1']))
	{
		$sub_id=$_POST['select1'];
		 $rs=mysql_query("Select * from mst_test where sub_id='$sub_id'",$connection);
			
			
			echo "<option></option>";
			while($row=mysql_fetch_array($rs))
			{  
				
				if($_POST['testselect']==$row[0])
				{
					echo "<option  value='$row[0]' selected>$row[2]</option>";	
				}	
				else
				{
					echo "<option  value='$row[0]'>$row[2]</option>";	
				}
				  
			
				
			}
			
	}
			echo'</select>';
			
			if(isset($_POST['testselect']))
			{     $test_id=$_POST['testselect'];
					$rs=mysql_query("Select * from mst_question where test_id='$test_id' ",$connection);
					   echo'<table>';
						echo"<tr><td>q_id</td><td>test_id</td><td>question</td><td>op1</td><td>op2</td><td>op3</td><td>op4</td><td>Correct ans</td></tr>";
					 while($row=mysql_fetch_array($rs))
					 {    
						   echo"<tr><a href=update.php?question_id='$row[0]'>'$row[0]'</a>";
						 echo"<td><input type=text value='$row[0]' name=q_id disabled></td>";
						 echo"<td><input type=text value='$row[1]' name=test_id></td>";
						 echo"<td><input type=text value='$row[2]' name=question></td>";
						 echo"<td><input type=text value='$row[3]' name=op1></td>";
						 echo"<td><input type=text value='$row[4]' name=op2></td>";
						 echo"<td><input type=text value='$row[5]' name=op3></td>";
						 echo"<td><input type=text value='$row[6]' name=op4></td>";
						 echo"<td><input type=text value='$row[7]' name=ans></td>";
						 echo"<td><input type=button name='$row[0]' value=Submit></td>";			
						 echo'</tr>';	
						 
                        $test_id=$row[1];						 
						 echo'</form>';
						 
					 }
				
			}
			 if(isset($_POST['question_id']))
			 {
				 echo "you are on right track";
				 
			 }
			?>
	</table>
	
	

		 </body>
</html>