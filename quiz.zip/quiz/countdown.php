
         
        <link rel="stylesheet" href="css/countdown.css">

    <h1 id="countheading">Countdown</h1>
<div id="clockdiv">
  
  <div>
    <span class="minutes"></span>
    <div class="smalltext">Minutes</div>
  </div>
  <div>
    <span class="seconds"></span>
    <div class="smalltext">Seconds</div>
  </div>
</div>
        <script src="js/countdown.js"></script>

