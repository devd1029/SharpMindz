<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>header</title>
<style type="text/css" rel="stylesheet">
a{
     text-decoration: none;
	color: #FFFFFF;
	font-family: "Agency FB";
	font-size: 15px;
	font-weight: lighter;
}
</style>
<link href="css/header.css" rel="stylesheet" >
</head>

<body>

<header id="tophead">
  
   <center>
	<table width="849"   class="tablenav">
  <tbody>
    <tr>
      <td width="89" scope="col">
     	 <div class="menuimg"><a href="index.php"><img src="img/home (2).png" width="70" height="56" alt=""></div>  
        </td>
      <td width="92" scope="col">
                 <div class="menuimg"></div>
       <a href="sampletest.php"><a href="starttest.php"><img src="img/sample1.png" width="71" height="55" alt=""/>  </a>     </td>
      <td width="98" scope="col"><a href="sublist.php"><img src="img/category1.png" width="63" height="60" alt=""/></a></td>
      <td width="112" scope="col"><a href="quiz.php"><img src="img/test1.png" width="66" height="56" alt=""/></a></td>
      <td width="97" scope="col"><a href="result.php"><img src="img/result1.png" width="67" height="58" alt=""/></a></td>
      <td width="118" scope="col"><a href="leaderboard.php"><img src="img/leaderboard1.png" width="71" height="61" alt=""/></a></td>
      <td width="105" scope="col"><a href="certificate.php"><img src="img/certificate1.png" width="82" height="65" alt=""/></a></td>
      <td width="102" scope="col"><a href="feedback.php"><img src="img/feedback1.png" width="68" height="62" alt=""/></a></td>
       
    </tr>
    <tr>
		<th height="20">
				<a href="index.php">	Home  </a>
		</th>
      <th>
			 <a href="starttest.php">Sample Test </a>
	  </th>
      <th> <a href="sublist.php">Category</a></th>
      <th width="112"> <a href="quiz.php">Online Test</a></th>
      <th width="97"> <a href="result.php">Result</a></th>
      <th width="118"> <a href="leaderboard.php">Leaderboard</a></th>
      <th width="105"> <a href="certificate.php">Certificate</a></th>
      <th width="102"> <a href="feedback.php">Feedback</a></th>       
    </tr>
  </tbody>
</table>
</center>
	<div class="circle" style="background-image: 
       url('images/bg6.jpg')">
</div>
</header>
</body>
</html>
